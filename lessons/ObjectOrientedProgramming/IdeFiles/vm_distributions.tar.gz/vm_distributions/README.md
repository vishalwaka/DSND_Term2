Gaussian distributions
Library to calculate gaussian and binomial distributions.

Getting Started
These instructions will install the library and running on your local machine for development.

Prerequisites
You need to have python and pip installed in your system.

Installing
A step by step process is as follows:

pip install vm-distributions