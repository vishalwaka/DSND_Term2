from setuptools import setup

setup(name='vm_distributions',
      version='1.0',
      description='Gaussian distributions',
      packages=['vm_distributions'],
      author = "Vishal Madheshia",
      author_email = "vishalmadheshia@gmail.com",
      zip_safe=False)
